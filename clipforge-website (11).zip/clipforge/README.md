# ClipForge — Stripe subscription checkout

## Start
Install Node 18+ and FFmpeg/FFprobe, then run `npm install` and `npm start`. Open http://localhost:3000.

## Enable actual payments
1. Create a Stripe account and activate payments. In Stripe Dashboard create **three recurring monthly prices** for $5 (Starter), $12 (Creator Pro), and $29 (Studio). Copy each **price ID**, not the product ID.
2. Set environment variables from `.env.example` on your Node hosting provider. `PUBLIC_URL` must be the deployed HTTPS origin (no trailing slash); `SESSION_SECRET` must be a long unpredictable random value. Environment variables are NOT automatically loaded from `.env.example`.
3. Deploy to a Node server that has FFmpeg installed. Test with Stripe test keys and test prices first, then replace with live keys and live prices when ready.
4. Enable and configure Stripe Customer Portal in the Stripe Dashboard so users can cancel or update billing.

The Choose buttons open Stripe-hosted subscription checkout. After successful payment, Stripe returns to ClipForge; the server verifies the checkout and subscription and sets a signed HttpOnly membership cookie. Premium concepts are served from `/api/member/concepts` only after server-side subscription verification. The manage button opens Stripe Customer Portal. Subscription status is checked against Stripe on requests, including after cancellation.

**Limitations:** There is no email/password account login or cross-device purchase restoration yet. The purchaser must return from checkout in the same browser; clearing browser cookies loses access until account recovery is implemented. A full production service should add secure authentication and recovery. No payments can occur until valid Stripe keys, price IDs, URL, and secret are configured. The clipper remains a basic evenly-spaced FFmpeg sampler; planned features are not implemented. The premium catalog contains clip *concepts*, not licensed downloadable footage. The $5 plan does not yet enforce upload quotas. Do not promise planned tools are already available.
